class Movies {
  // Private fields
  #list = [];

  // Public properties
  get movieList() {
    return this.#list;
  }

  // Public Methods
  getAll() {
    this.#list = [
      {
        "filmId": 1,
        "name": "2012",
        "genres": "Action,Adventure,Sci-Fi",
        "actors": "John Cusack,Amanda Peet",
        "runTimeInMinutes": 158,
        "rating": "PG-13",
        "price": 3.95,
        "releaseDate": "2009-11-13"
      },
      {
        "filmId": 2,
        "name": "9 to 5",
        "genres": "Comedy",
        "actors": "Jane Fonda,Lily Tomlin,Dolly Parton",
        "runTimeInMinutes": 109,
        "rating": "PG",
        "price": 2.95,
        "releaseDate": "1980-12-19"
      },
      {
        "filmId": 5,
        "name": "African Queen, The",
        "genres": "Adventure,Drama,Romance",
        "actors": "Humphrey Bogart,Katharine Hepburn",
        "runTimeInMinutes": 105,
        "rating": "G",
        "price": 3.95,
        "releaseDate": "1952-02-20"
      },
      {
        "filmId": 6,
        "name": "Alien",
        "genres": "Horror,Sci-Fi",
        "actors": "Sigourney Weaver",
        "runTimeInMinutes": 117,
        "rating": "R",
        "price": 3.95,
        "releaseDate": "1979-05-25"
      }
    ];
  }
}