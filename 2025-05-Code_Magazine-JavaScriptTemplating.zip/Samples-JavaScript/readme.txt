single-value
single-value-no-input
multi-value
multi-value-literal
template
table-single-row
table