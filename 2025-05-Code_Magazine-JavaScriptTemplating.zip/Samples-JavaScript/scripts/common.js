function getValue(id) {
  return document.getElementById(id).value;
}

function getElement(id) {
  return document.getElementById(id);
}

function formatCurrency(value) {
  return new Number(value)
  .toLocaleString("en-US", 
    { "style": "currency",
     "currency": "USD" });
}